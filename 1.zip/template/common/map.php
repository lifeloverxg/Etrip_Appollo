<section class="section-map">
	<img class="map-image" src="<?php echo $home.$map['url']; ?>" alt="<?php echo $map['alt']; ?>" title="<?php echo $map['title']; ?>"/>
</section>