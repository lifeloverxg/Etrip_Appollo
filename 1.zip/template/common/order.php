	<section class="section-order">
		<div class="info-title">
			<p>订单查询</p>
		</div>
		<div class="order-track">
			<div class="yellow-underline">
				<p>最新订单跟踪</p>
				<div class="underline"></div>
			</div>
			<div class="description-content">
				2014-03-15————2014-03-18<br>
				芝加哥深度4日游(纽约出发)
				订单状态：已经出票
			</div>
			<button class="travel-button" onclick="javascript: ">历史订单</button>
		</div>
	</section>