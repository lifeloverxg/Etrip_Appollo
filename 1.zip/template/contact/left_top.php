<section class="section-contact-left-top">
<?php
include $home . "template/contact/calendar.php";
include $home . "template/contact/recent_event.php";
?>
</section>