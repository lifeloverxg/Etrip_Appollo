<section class="section-contact-join">
    <div class="info-title">加入我们</div>
</section>