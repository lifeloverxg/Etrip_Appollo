<section class="section-contact-recent">
    <div class="info-title">近期事件</div>
    <div class="recent-event">
        <?php echo $recent_event; ?>
    </div>
</section>