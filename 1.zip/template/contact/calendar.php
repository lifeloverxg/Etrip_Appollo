<section class="section-contact-calendar">
    <div class="info-title">日历</div>
    <div class="contact-calendar">
        <img src="<?php echo $home . 'images/contact_cal.jpg'; ?>">
    </div>
</section>