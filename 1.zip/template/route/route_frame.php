<?php
// HTML header
include $home . "template/common/header.php";
?>
<?php
//HTML body
include $home . "template/common/route_list.php";
?>
<?php
// HTML footer
include $home . "template/common/footer.php";
?>