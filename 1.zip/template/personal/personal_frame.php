<?php
// HTML header
include $home . "template/common/header.php";
?>
<div class="left-main-wrap">
<?php
// HTML left panel
include $home . "template/personal/left_frame.php";
include $home . "template/personal/right_frame.php";
?>
</div>
<?php
// HTML footer
include $home . "template/common/map.php";
include $home . "template/common/footer.php";
?>