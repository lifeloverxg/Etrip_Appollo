	<section class="section-about">
		<div class="info-title">
			<p>关于我</p>
		</div>
		<div class="personal-description">
			<div class="title-underline">
				<p>个人简介</p>
				<div class="underline"></div>
			</div>
			<div class="description-content">
				最近旅行：2013.5 墨西哥坎昆7日游<br>
				未来旅行愿望：阿拉斯加看极光，乞力马扎罗山
			</div>
		</div>
	</section>