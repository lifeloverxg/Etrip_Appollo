	<section class="view-right">
<?php
include $home . "template/personal/right_top_frame.php";
include $home . "template/common/image_list.php";
?>
	</section>