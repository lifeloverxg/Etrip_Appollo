	<section class="view-right-top-left">
<?php
include $home . "template/common/order.php";
include $home . "template/common/trip_plan.php";
?>
	</section>