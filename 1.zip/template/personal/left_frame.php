	<section class="view-left">
<?php 
include $home . "template/personal/aboutme.php";
include $home . "template/common/feed.php";
?>
	</section>