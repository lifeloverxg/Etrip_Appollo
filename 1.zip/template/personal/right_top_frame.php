	<section class="view-right-top">
<?php
include $home . "template/personal/right_top_left_frame.php";
include $home . "template/personal/trip_diary.php";
?>
	</section>