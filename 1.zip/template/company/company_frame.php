<?php
// HTML header
include $home . "template/common/header.php";
?>
<section class="section-middle">
    <section class="section-company-left">
<?php
// HTML left panel
include $home . "template/company/left_frame.php";
?>

    </section>
    
<?php
// HTML left panel
include $home . "template/company/description.php";
?>

</section>
<?php
// HTML footer
include $home . "template/common/footer.php";
?>