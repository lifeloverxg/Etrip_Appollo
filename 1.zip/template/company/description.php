<section class="section-company-description">
    <div class="info-title">公司介绍</div>
    <div class="company-description">
        <div class="description-info">
            <?php echo $description; ?>
        </div>
        <div class="description-comment">
            <label style="color: yellow;">给我们留言：</label><br>
            <textarea placeholder="请输入内容"></textarea>
            <button class="travel-button" style="float: right;">发表留言</button>
        </div>
    </div>
</section>