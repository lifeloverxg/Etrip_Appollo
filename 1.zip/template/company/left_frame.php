<section class="section-company-left-top">
<?php
include $home . "template/company/left_top_left.php";
include $home . "template/company/service.php";
?>
</section>

<?php
// HTML left panel
include $home . "template/common/image_list.php";
?>