<section class="section-company-left-top-left">
<?php
include $home . "template/company/info.php";
include $home . "template/company/department.php";
?>
</section>