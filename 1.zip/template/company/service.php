<section class="section-company-service">
    <div class="info-title">公司服务</div>
    <div class="service-cell">
        <img src="<?php echo $home . $image_list['customer']; ?>" class="service-img">
        <div class="service-title">客户追踪服务</div>
    </div>
    <div class="service-cell">
        <div class="service-title">市场推广服务</div>
        <img src="<?php echo $home . $image_list['market']; ?>" class="service-img">
    </div>
    <div class="service-cell">
        <img src="<?php echo $home . $image_list['travel']; ?>" class="service-img">
        <div class="service-title">旅行定制服务</div>
    </div>
    <div class="service-cell">
        <div class="service-title">私人旅游服务</div>
        <img src="<?php echo $home . $image_list['private']; ?>" class="service-img">
    </div>
</section>